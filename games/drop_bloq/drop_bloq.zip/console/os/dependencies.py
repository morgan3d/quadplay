"This file is read by both Python and JavaScript, so it has a strange syntax and filename"
os_dependencies = {
   "$font3":              "quad://fonts/deja-3.font.json",
   "$font5":              "quad://fonts/deja-5.font.json",
   "$font6":              "quad://fonts/deja-6.font.json",
   "$font8":              "quad://fonts/deja-8.font.json",
   "$font9":              "quad://fonts/deja-9.font.json",
   "$font15":             "quad://fonts/deja-15.font.json",
   "$moveUISound":        "quad://sounds/blip-04.sound.json",
   "$acceptUISound":      "quad://sounds/jump-08.sound.json",
   "$openUISound":        "quad://sounds/powerup-03.sound.json",
   "$cancelUISound":      "quad://sounds/shoot-08.sound.json",
   "$denyUISound":        "quad://sounds/hit-06.sound.json",
   "$quadplayLogoSprite": "quad://console/os/logo.sprite.json",
   "$opaqueSprite":       "quad://console/os/opaque.sprite.json",
   "$controllerSpritesheet22": "quad://sprites/controllers-32x22.sprite.json",
   "$controllerSpritesheet44": "quad://sprites/controllers-64x44.sprite.json"
}
