// Export script by Morgan McGuire 2020. Released into the public domain.
// https://casual-effects.com/g3d
#include <G3D/G3D.h>
G3D_START_AT_MAIN();

void exportCar() {
    ParseOBJ parser;
    BinaryInput input("quad-car.obj", G3DEndian::G3D_LITTLE_ENDIAN);
    parser.parse(input);

    TextOutput output("quad-car.pyxl");
    output.writeSymbols("mesh", "=", "{");
    output.writeNewline();
    output.pushIndent();
    output.writeSymbols("vertex_array", ":", "[");
    output.writeNewline();
    output.pushIndent();
    for (const Point3& v : parser.vertexArray) {
        output.printf("xyz(%f, %f, %f),\n", v.x, v.y, v.z);
    }
    output.writeNewline();
    output.writeSymbols("],");
    output.writeNewline();
    output.popIndent();

    output.writeSymbols("line_array", ":", "[");
    output.pushIndent();
    // Only generate each line once, although each will appear in at least two faces
    Set<int> alreadySeen;
    for (const ParseOBJ::GroupTable::Entry& groupEntry : parser.groupTable) {
        for (const ParseOBJ::MeshTable::Entry& meshEntry : groupEntry.value->meshTable) {
            for (const ParseOBJ::Face& face : meshEntry.value->faceArray) {
                const int N = face.size();
                for (int i = 0; i < N; ++i) {
                    const int A = face[i].vertex, B = face[(i + 1) % N].vertex;
                    alwaysAssertM(A >= 0 && B >= 0 && A < 65536 && B < 65536, "Too many faces");
                    const int edgeIndex = (max(A, B) << 16) + min(A, B);
                    if (!alreadySeen.contains(edgeIndex)) {
                        output.printf("%d, %d,\n", A, B);
                        alreadySeen.insert(edgeIndex);
                    }
                }
            }
        }
    }
    output.popIndent();
    output.writeSymbol("]");
    output.writeNewline();
    output.popIndent();
    output.writeSymbol("}");

    output.commit();
}

int main(int argc, const char* argv[]) {
    initGLG3D(G3DSpecification());
    exportCar();
    return 0;
}
